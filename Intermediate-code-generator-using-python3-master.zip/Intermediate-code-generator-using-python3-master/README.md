# Intermediate code generator (CODE GENERATOR) using python

It is basically a python program for generating an intermediate three address code.

It takes  .csv file formate for input.

In this there is left and right columns indicates the "left" and "right" values respectively.

The csv file doesn't contains "=" sign.

# Code Generator

**Code generator** is used to produce the target code for three-address statements. It uses registers to store the operands of the three address statement.

**Any suggestation regarding this program is helpful for me**
